ArpYourBase 1.0

This was written to delete the ARP entries on PC workstations every 200 seconds or so to 
compensate for a bug in Airport and the PC.  This is not necessary except on Windows-95 
and Windows-98.  W-2000 and NT can tune their ARP timings.

Install by running setup.exe from the setup subdirectory (although the .exe files might just work
if you have installed other VB 5.0 stuff).

The values for seconds and the IP address are stored automatically in the registry.  You can cause the 
program to autostart and be hidden by making a copy of the file arpyourbase.exe as
autoyourbase.exe and making it part of the startup.

To keep things simple, this is not a nifty system tray program nor is it a service.  It simply waits
for a while and then calls a shell command.

In order to make sure that there is not too many copies of the program, each instance of the program
check a variable in the registry once every 60 seconds called "session" and when a new instance 
comes into being all the other instances will exit within 60 seconds.

You can also kill instances using CTRL-ALT-DEL.

drchuck@sourceforge.com